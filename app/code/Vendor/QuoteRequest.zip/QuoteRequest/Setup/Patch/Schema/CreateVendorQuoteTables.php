<?php
namespace Vendor\QuoteRequest\Setup\Patch\Schema;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\SchemaPatchInterface;
use Magento\Framework\DB\Ddl\Table;

class CreateVendorQuoteTables implements SchemaPatchInterface
{
    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    public function apply()
    {
        $setup = $this->moduleDataSetup;
        $setup->startSetup();

        // vendor_quote table
        if (!$setup->tableExists('vendor_quote')) {
            $table = $setup->getConnection()->newTable($setup->getTable('vendor_quote'))
                ->addColumn('quote_id', Table::TYPE_INTEGER, null, [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ], 'Quote ID')
                ->addColumn('customer_id', Table::TYPE_INTEGER, null, ['unsigned' => true, 'nullable' => true], 'Customer ID')
                ->addColumn('vendor_id', Table::TYPE_INTEGER, null, ['unsigned' => true, 'nullable' => true], 'Vendor ID')
                ->addColumn('status', Table::TYPE_TEXT, 50, ['nullable' => false, 'default' => 'pending'], 'Quote Status')
                ->addColumn('country_id', Table::TYPE_TEXT, 10, ['nullable' => true], 'Country ID')
                ->addColumn('region_id', Table::TYPE_TEXT, 255, ['nullable' => true], 'Region ID')
                ->addColumn('customer_note', Table::TYPE_TEXT, '64k', ['nullable' => true], 'Customer Note')
                ->addColumn('created_at', Table::TYPE_TIMESTAMP, null, ['nullable' => false, 'default' => Table::TIMESTAMP_INIT], 'Created At')
                ->addIndex($setup->getIdxName('vendor_quote', ['customer_id']), ['customer_id'])
                ->addIndex($setup->getIdxName('vendor_quote', ['vendor_id']), ['vendor_id'])
                ->setComment('Vendor Quote Table');

            $setup->getConnection()->createTable($table);
        }

        // vendor_quote_item table
        if (!$setup->tableExists('vendor_quote_item')) {
            $table = $setup->getConnection()->newTable($setup->getTable('vendor_quote_item'))
                ->addColumn('item_id', Table::TYPE_INTEGER, null, [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ], 'Item ID')
                ->addColumn('quote_id', Table::TYPE_INTEGER, null, ['unsigned' => true, 'nullable' => false], 'Quote ID')
                ->addColumn('product_id', Table::TYPE_INTEGER, null, ['unsigned' => true, 'nullable' => false], 'Product ID')
                ->addColumn('qty', Table::TYPE_INTEGER, null, ['nullable' => false], 'Quantity')
                ->addColumn('proposed_price', Table::TYPE_DECIMAL, '12,2', ['nullable' => true], 'Proposed Price')
                ->addIndex($setup->getIdxName('vendor_quote_item', ['product_id']), ['product_id'])
                ->addForeignKey(
                    $setup->getFkName('vendor_quote_item', 'quote_id', 'vendor_quote', 'quote_id'),
                    'quote_id',
                    $setup->getTable('vendor_quote'),
                    'quote_id',
                    Table::ACTION_CASCADE
                )
                ->setComment('Vendor Quote Items');

            $setup->getConnection()->createTable($table);
        }

        $setup->endSetup();
    }

    public static function getDependencies()
    {
        return [];
    }

    public function getAliases()
    {
        return [];
    }
}